<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: "App"
};
</script>

<style>
body {
  margin: 0;
  padding: 0;
  font-size: 14px;
  background-color: #f1f1f1;
  font-family: PingFangSC-Regular;
  font-size: 12px;
  color: #333333;
}
</style>
